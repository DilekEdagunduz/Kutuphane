﻿using System;
using CSharpOOP.Models;
using CSharpOOP.Games;
using CSharpOOP.BankSample;
using CSharpOOP.HastaneOrnek;
using CSharpOOP.OkulOrnek;
using CSharpOOP.Kutuphane;

namespace CSharpOOP
{
   public class Program
    {
        static void Main(string[] args)
        {

            Fakulte fakulte = new Fakulte("Fen");



            Bolum bolum = new Bolum();
            bolum.Ad = "Fizik";
            bolum.Fakulte = fakulte;



            //Bölümün fakültesinin adını büyük harflerle ekrana yaz!
            Console.WriteLine(bolum.Fakulte.Ad);



            #region Kutuphane

            Tur tur = new Tur("Masal");
            Yayinevi yayinevi = new Yayinevi("Denizbank", 2000);

            Uye uye = new Uye("Dilek Eda", "Gündüz", "12345678910", "istanbul","5555555123");

            Kitap kitap = new Kitap("Pamuk Prenses", DateTime.Now, tur,yayinevi, "Okuma" );

           
            Kutuphaneİslem kutuphaneislem = new Kutuphaneİslem();

            DateTime newdate = new DateTime(2022, 04, 10);

            kutuphaneislem.kitapal(uye, kitap.Ad, newdate);
            kutuphaneislem.kitapiade(uye, kitap.Ad, DateTime.Now);








            #endregion




            #region hastaneSample
            Poliklinik poliklinik = new Poliklinik("KBB", 2000);


            Doktor doktor = new Doktor("Çağatay","Yıldız", poliklinik);
            Doktor doktor1 = new Doktor("Abdullah", "Tekin", poliklinik);

            Hasta hasta = new Hasta();
            hasta.Ad = "Mert";
            hasta.DogumTarih = new DateTime(1998, 1, 1);
            hasta.TCNo = "8842812491";


            Islem islem = new Islem();
            islem.Doktor = doktor;
            islem.Hasta = hasta;
            islem.IslemTarihi = DateTime.Now;
            islem.Not = "Grip olmuşum";

            //Bu işlemin olduğu polikliniği adı nedir?
            Console.WriteLine(islem.Doktor.Poliklinik.Ad);



            #endregion



            #region bankAccountSample
            BankAccount bankAccount = new BankAccount("Çağatay", 1000);


            while (true)
            {
                Console.WriteLine("Lütfen işlem tutarını giriniz.");
                decimal amount = Convert.ToDecimal(Console.ReadLine());

                Console.WriteLine("Lütfen işlem notunu giriniz");
                string note = Console.ReadLine();

                Console.WriteLine("İşleminiz para yatırma ise D çekme ise W tuşuna basıp entera basınız!");

                string operation = Console.ReadLine().ToLower();

                if (operation == "d")
                {
                    bankAccount.MakeDeposit(amount, DateTime.Now, note);
                }
                else if (operation == "w")
                {
                    bankAccount.MakeWithdrawal(amount, DateTime.Now, note);
                }
                else
                {
                    break;
                }

                Console.WriteLine("İşlem sonrasın mevcut bakiyeniz: " + bankAccount.Balance);

            }

            #endregion



            //Batman batman = new Batman("Çağatay", "Erzurum");
            //Batman batman1 = new Batman();


            //Ninject ninject = new Ninject();
            //ninject.Hello();


            #region OOP-Sample-1

            //Instance aldım!

            Category category = new Category();
            category.Id = 3;
            category.Name = "Sport";
            category.Description = "Sport products";

            Supplier supplier = new Supplier();
            supplier.Country = "iran";
            supplier.CompanyName = "Siemens";
            supplier.ContactName = "Alp";


            Product product = new Product();
            product.Name = "IPhone";
            product.UnitPrice = 55;
            product.Category = category; //boxing
            product.Supplier = supplier; //boxing


            //Yukarıda instance alınan product ın categorysinin adını console a yazdır
            // Console.WriteLine(product.Category.Name); //unboxing

            //Yukarıda instance alınan product ın suppler ının companyName console a yazdır. DİLEK?
            // Console.WriteLine(product.Supplier.CompanyName); //unboxing

            Console.WriteLine(product);
            Console.ReadLine();

            #endregion

        }
    }
}
