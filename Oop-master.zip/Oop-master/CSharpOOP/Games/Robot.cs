﻿using System;
namespace CSharpOOP.Games
{
    public class Robot : GameCharachter
    {
        public string Model { get; set; }

        public string City { get; set; }
    }
}
