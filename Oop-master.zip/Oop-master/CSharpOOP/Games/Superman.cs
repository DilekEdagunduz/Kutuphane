﻿using System;
namespace CSharpOOP.Games
{
    public class Superman
    {
        public Superman()
        {
        }
    }
}
