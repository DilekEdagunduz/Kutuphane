﻿using System;
namespace CSharpOOP.OkulOrnek
{
    public class Akademisyen
    {
        public string Ad { get; set; }

        public string Soyad { get; set; }

        public Bolum Bolum { get; set; }
    }
}
