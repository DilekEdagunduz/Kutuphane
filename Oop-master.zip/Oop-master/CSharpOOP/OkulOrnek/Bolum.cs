﻿using System;
namespace CSharpOOP.OkulOrnek
{
    public class Bolum
    {
        public string Ad { get; set; }
        public Fakulte Fakulte { get; set; }
    }
}
