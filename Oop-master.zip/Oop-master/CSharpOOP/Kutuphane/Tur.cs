﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpOOP.Kutuphane
{
    public class Tur
    {
        public string Ad { get; set; }

        public Tur(string ad) { Ad = ad; }
    }
}
