﻿using System;
namespace CSharpOOP.HastaneOrnek
{
    public class Islem
    {
        public Doktor Doktor { get; set; }

        public Hasta Hasta { get; set; }

        public string Not { get; set; }

        public DateTime IslemTarihi { get; set; }

    }
}
