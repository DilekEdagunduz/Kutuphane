﻿using System;
namespace CSharpOOP.HastaneOrnek
{
    public class Hasta : BaseModel
    {
        public string Soyad { get; set; }

        public DateTime DogumTarih { get; set; }

        public string TCNo { get; set; }

     }
}
